/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author neto_
 */
public class ModelDisciplina {

    private int idDisciplina;
    private String nome;
    private int cargaHoraria;
    private ModelPropostaCurso modelPropostaCurso;

    public ModelDisciplina() {
    }

    public ModelDisciplina(int idDisciplina, String nome, int cargaHoraria, ModelPropostaCurso modelPropostaCurso) {
        this.idDisciplina = idDisciplina;
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.modelPropostaCurso = modelPropostaCurso;
    }

    public int getIdDisciplina() {
        return idDisciplina;
    }

    public void setIdDisciplina(int idDisciplina) {
        this.idDisciplina = idDisciplina;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public ModelPropostaCurso getModelPropostaCurso() {
        return modelPropostaCurso;
    }

    public void setModelPropostaCurso(ModelPropostaCurso modelPropostaCurso) {
        this.modelPropostaCurso = modelPropostaCurso;
    }

}
