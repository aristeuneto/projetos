/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import conexao.ConexaoJDBC;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author neto_
 */
public class Principal {

    public static void main(String[] args) {

        Connection conn = null;

        conn = ConexaoJDBC.conectar();

        ModelPropostaCurso modelPropostaCurso = new ModelPropostaCurso();
        
        String nomeCurso = "ADS3";
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from tbl_proposta_curso where curs_nome = '" + nomeCurso + "'");
            stmt.execute();
            ResultSet rs = stmt.getResultSet();
            while (rs.next()) {
                modelPropostaCurso.setIdPropostaCurso(rs.getInt("pk_proposta_curso"));
                modelPropostaCurso.setNome(rs.getString("curs_nome"));
                modelPropostaCurso.setDescricao(rs.getString("curs_descricao"));
                modelPropostaCurso.setPerfilEgresso(rs.getString("curs_perfil_egresso"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();

        }
        
        System.out.println(modelPropostaCurso.getDescricao());
    }
}
