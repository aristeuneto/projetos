/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author neto_
 */
public class ModelBibliografia {

    private int idDisciplina;
    private String descricao;
    private String tipo;
    private ModelDisciplina modelDisciplina;

    public ModelBibliografia() {
    }

    public ModelBibliografia(int idDisciplina, String descricao, String tipo, ModelDisciplina modelDisciplina) {
        this.idDisciplina = idDisciplina;
        this.descricao = descricao;
        this.tipo = tipo;
        this.modelDisciplina = modelDisciplina;
    }

    public int getIdDisciplina() {
        return idDisciplina;
    }

    public void setIdDisciplina(int idDisciplina) {
        this.idDisciplina = idDisciplina;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public ModelDisciplina getModelDisciplina() {
        return modelDisciplina;
    }

    public void setModelDisciplina(ModelDisciplina modelDisciplina) {
        this.modelDisciplina = modelDisciplina;
    }

}
