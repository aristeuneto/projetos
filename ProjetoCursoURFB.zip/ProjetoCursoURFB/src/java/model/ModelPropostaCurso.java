/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author neto_
 */
public class ModelPropostaCurso {

    private int idPropostaCurso;
    private String nome;
    private String descricao;
    private String perfilEgresso;

    public ModelPropostaCurso() {
    }

    public ModelPropostaCurso(int idPropostaCurso, String nome, String descricao, String perfilEgresso) {
        this.idPropostaCurso = idPropostaCurso;
        this.nome = nome;
        this.descricao = descricao;
        this.perfilEgresso = perfilEgresso;
    }

    public int getIdPropostaCurso() {
        return idPropostaCurso;
    }

    public void setIdPropostaCurso(int idPropostaCurso) {
        this.idPropostaCurso = idPropostaCurso;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getPerfilEgresso() {
        return perfilEgresso;
    }

    public void setPerfilEgresso(String perfilEgresso) {
        this.perfilEgresso = perfilEgresso;
    }

}
