/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Cpd01
 */
public class ConexaoJDBC {

    private static final String banco = "db_curso_urfb";  //final = variável constante(não muda o valor)
    private static final String user = "root";
    private static final String password = "root";
    private static final String servidor = "127.0.0.1";
    private static final String porta = "3307";
    private static Connection conn = null;

    public ConexaoJDBC() {
    }

    static public Connection conectar() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            ConexaoJDBC.conn = DriverManager.getConnection("jdbc:mysql://"+servidor+":"+porta+"/" +banco, user, password);
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return conn;

    }

}
