/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexao.ConexaoJDBC;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ModelBibliografia;
import model.ModelDisciplina;

/**
 *
 * @author neto_
 */
public class DaoBibliografia {

    Connection conn = null;

    public DaoBibliografia() {

        this.conn = ConexaoJDBC.conectar();

    }

    public void Salvar(ModelBibliografia modelBibliografia) {

        try {
            PreparedStatement stmt = conn.prepareStatement("insert into tbl_bibliografia (bibli_descricao, bibli_tipo, id_disciplina)"
                    + " values (?,?,?)");
            stmt.setString(1, modelBibliografia.getDescricao());
            stmt.setString(2, String.valueOf(modelBibliografia.getTipo()));
            stmt.setInt(3, modelBibliografia.getModelDisciplina().getIdDisciplina());
            stmt.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }

    public void Excluir(int idBibliografia) {
        try {
            PreparedStatement stmt = conn.prepareStatement("delete from tbl_bibliografia where pk_bibliografia = (?)");
            stmt.setInt(1, idBibliografia);
            stmt.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void Alterar(ModelBibliografia modelBibliografia, ModelDisciplina modelDisciplina) {

        try {
            PreparedStatement stmt = conn.prepareStatement("update tbl_bibliografia set bibli_descricao = (?), bibli_tipo = (?), id_disciplina = (?) "
                    + "where pk_bibliografia = " + modelBibliografia.getIdDisciplina() + " ");

            stmt.setString(1, modelBibliografia.getDescricao());
            stmt.setString(2, modelBibliografia.getTipo());
            stmt.setInt(3, modelDisciplina.getIdDisciplina());
            stmt.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public List<ModelBibliografia> listaDeModelBibliografia() {
        List<ModelBibliografia> listaDeModelBibliografias = new ArrayList<>();
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from tbl_bibliografia");
            stmt.execute();
            ResultSet rs = stmt.getResultSet();
            while (rs.next()) {
                ModelBibliografia modelBibliografia = new ModelBibliografia();
                modelBibliografia.setIdDisciplina(Integer.parseInt(rs.getString("pk_bibliografia")));
                modelBibliografia.setDescricao(rs.getString("bibli_descricao"));
                modelBibliografia.setTipo(rs.getString("bibli_tipo"));
                listaDeModelBibliografias.add(modelBibliografia);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return listaDeModelBibliografias;
    }

    public ModelBibliografia buscarPorId(int idBibliografia) {
        ModelBibliografia modelBibliografia = null;
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from tbl_bibliografia where pk_bibliografia = "
                    + "" + idBibliografia + "");
            modelBibliografia = (ModelBibliografia) stmt.getResultSet();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return modelBibliografia;
    }
}
