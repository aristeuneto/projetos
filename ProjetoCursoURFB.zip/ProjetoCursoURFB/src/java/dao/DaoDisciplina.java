/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexao.ConexaoJDBC;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.ModelBibliografia;
import model.ModelDisciplina;
import model.ModelPropostaCurso;

/**
 *
 * @author neto_
 */
public class DaoDisciplina {

    Connection conn = null;

    public DaoDisciplina() {

        this.conn = ConexaoJDBC.conectar();

    }

    public void Salvar(ModelDisciplina modelDisciplina) {

        try {
            PreparedStatement stmt = conn.prepareStatement("insert into tbl_disciplina (disc_nome, disc_carga_horaria, id_proposta_curso)"
                    + " values (?,?,?)");
            stmt.setString(1, modelDisciplina.getNome());
            stmt.setInt(2, modelDisciplina.getCargaHoraria());
            stmt.setInt(3, modelDisciplina.getModelPropostaCurso().getIdPropostaCurso());
            stmt.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }

    public void Excluir(int idDisciplina) {
        try {
            PreparedStatement stmt = conn.prepareStatement("delete from tbl_disciplina where pk_disciplina = (?)");
            stmt.setInt(1, idDisciplina);
            stmt.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void Alterar(ModelDisciplina modelDisciplina, ModelPropostaCurso modelPropostaCurso) {
        DaoPropostaCurso daoPropostaCurso = new DaoPropostaCurso();
    //    ModelPropostaCurso modelPropostaCurso = daoPropostaCurso.buscarPorNome();
        
        try {
            PreparedStatement stmt = conn.prepareStatement("update tbl_disciplina set disc_nome = (?), disc_carga_horaria = (?), id_proposta_curso = (?) "
                    + "where pk_disciplina = "+modelDisciplina.getIdDisciplina()+" ");
                 
            stmt.setString(1, modelDisciplina.getNome());
            stmt.setInt(2, modelDisciplina.getCargaHoraria());
            stmt.setInt(3, modelPropostaCurso.getIdPropostaCurso());
            stmt.execute();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public List<ModelDisciplina> listaDeModelDisciplina() {
        List<ModelDisciplina> listaDeModelDisciplina = new ArrayList<>();
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from tbl_disciplina");
            stmt.execute();
            ResultSet rs = stmt.getResultSet();

            while (rs.next()) {
                ModelDisciplina modelDisciplina = new ModelDisciplina();
                modelDisciplina.setIdDisciplina(rs.getInt("pk_disciplina"));
                modelDisciplina.setNome(rs.getString("disc_nome"));
                modelDisciplina.setCargaHoraria(rs.getInt("disc_carga_horaria"));

                listaDeModelDisciplina.add(modelDisciplina);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return listaDeModelDisciplina;
    }

    public ModelDisciplina buscarPorId(int idDisciplina) {
        ModelDisciplina modelDisciplina = null;
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from tbl_disciplina where pk_disciplina = "
                    + "" + idDisciplina + "");
            modelDisciplina = (ModelDisciplina) stmt.getResultSet();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return modelDisciplina;
    }
    
     public ModelDisciplina buscarPorNome(String nomeDisciplina) {

        ModelDisciplina modelDisciplina = new ModelDisciplina();
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from tbl_disciplina where disc_nome = '" + nomeDisciplina + "'");
            stmt.execute();
            ResultSet rs = stmt.getResultSet();
            while (rs.next()) {
                modelDisciplina.setIdDisciplina(rs.getInt("pk_disciplina"));
                modelDisciplina.setNome(rs.getString("disc_nome"));
                modelDisciplina.setCargaHoraria(rs.getInt("disc_carga_horaria"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return modelDisciplina;
    }
}
