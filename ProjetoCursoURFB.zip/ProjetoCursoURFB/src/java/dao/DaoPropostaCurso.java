/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import conexao.ConexaoJDBC;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import model.ModelPropostaCurso;

/**
 *
 * @author neto_
 */
public class DaoPropostaCurso {

    Connection conn = null;

    public DaoPropostaCurso() {

        this.conn = ConexaoJDBC.conectar();

    }

    public void Salvar(ModelPropostaCurso modelPropostaCurso) {

        try {
            PreparedStatement stmt = conn.prepareStatement("insert into tbl_proposta_curso (curs_nome, curs_descricao, curs_perfil_egresso) values (?,?,?)");
            stmt.setString(1, modelPropostaCurso.getNome());
            stmt.setString(2, modelPropostaCurso.getDescricao());
            stmt.setString(3, modelPropostaCurso.getPerfilEgresso());
            stmt.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }

    public void Excluir(int idPropostaCurso) {
        try {
            PreparedStatement stmt = conn.prepareStatement("delete from tbl_proposta_curso where pk_proposta_curso = (?)");
            stmt.setInt(1, idPropostaCurso);
            stmt.execute();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Buscar o ModelPropostaCurso por ID e alterar no método abaixo
     *
     * @param modelPropostaCurso
     */
    public void Alterar(ModelPropostaCurso modelPropostaCurso) {

        try {
            PreparedStatement stmt = conn.prepareStatement("update tbl_proposta_curso set curs_nome = (?), curs_descricao = (?),"
                    + " curs_perfil_egresso = (?) where pk_proposta_curso = " + modelPropostaCurso.getIdPropostaCurso() + " ");
            stmt.setString(1, modelPropostaCurso.getNome());
            stmt.setString(2, modelPropostaCurso.getDescricao());
            stmt.setString(3, modelPropostaCurso.getPerfilEgresso());
            stmt.execute();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }

    public List<ModelPropostaCurso> listaDeModelPropostaDeCurso() {
        List<ModelPropostaCurso> listaDeModelPropostaDeCurso = new ArrayList<ModelPropostaCurso>();
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from tbl_proposta_curso");
            stmt.execute();
            ResultSet rs = stmt.getResultSet();

            while (rs.next()) {
                ModelPropostaCurso modelPropostaCurso = new ModelPropostaCurso();
                modelPropostaCurso.setIdPropostaCurso(rs.getInt("pk_proposta_curso"));
                modelPropostaCurso.setNome(rs.getString("curs_nome"));
                modelPropostaCurso.setDescricao(rs.getString("curs_descricao"));
                modelPropostaCurso.setPerfilEgresso(rs.getString("curs_perfil_egresso"));

                listaDeModelPropostaDeCurso.add(modelPropostaCurso);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return listaDeModelPropostaDeCurso;
    }

    public ModelPropostaCurso buscarPorId(int idPropostaCurso) {
        ModelPropostaCurso modelPropostaCurso = null;
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from tbl_proposta_curso where pk_proposta_curso = "
                    + "" + idPropostaCurso + "");
            modelPropostaCurso = (ModelPropostaCurso) stmt.getResultSet();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return modelPropostaCurso;
    }

    public ModelPropostaCurso buscarPorNome(String nomeCurso) {

        ModelPropostaCurso modelPropostaCurso = new ModelPropostaCurso();
        try {
            PreparedStatement stmt = conn.prepareStatement("select * from tbl_proposta_curso where curs_nome = '" + nomeCurso + "'");
            stmt.execute();
            ResultSet rs = stmt.getResultSet();
            while (rs.next()) {
                modelPropostaCurso.setIdPropostaCurso(rs.getInt("pk_proposta_curso"));
                modelPropostaCurso.setNome(rs.getString("curs_nome"));
                modelPropostaCurso.setDescricao(rs.getString("curs_descricao"));
                modelPropostaCurso.setPerfilEgresso(rs.getString("curs_perfil_egresso"));
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {

            try {
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return modelPropostaCurso;
    }

}
